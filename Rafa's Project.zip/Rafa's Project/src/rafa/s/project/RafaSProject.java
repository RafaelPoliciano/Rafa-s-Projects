/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rafa.s.project;

/**
 *
 * @author rafael.psilva70
 */
public class RafaSProject {
    public static void frase(){
        System.out.println("Hello World");
    }
    public static void flor(){
        System.out.println("Abra a mente e absorva a flor");
    }
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frase();
        flor();
        frase();
    }
    
}
