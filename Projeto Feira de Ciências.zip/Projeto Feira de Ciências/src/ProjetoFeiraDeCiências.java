/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.SystemColor;
import static java.awt.SystemColor.text;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

    private static SystemColor button;
    private static SystemColor labe;
/**
 *
 * @author rafael.psilva70
 */
public class ProjetoFeiraDeCiências {
    public static void main(String[] args) {
        // Criação da janela
        JFrame frame = new JFrame("Exemplo de Interface");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new FlowLayout());

        // Declaração das variáveis fora de qualquer bloco
        JTextField textField = new JTextField(20);
        JButton button = new JButton("Exibir Texto");
        JLabel label = new JLabel();

        // Configurações do campo de texto
        textField.setFont(new Font("Arial", Font.PLAIN, 16)); // Define a fonte do campo de texto

        // Configurações do rótulo
        label.setFont(new Font("Arial", Font.BOLD, 16)); // Define a fonte do rótulo
        label.setEnabled(false); // Desabilita a edição do rótulo
        
         button.addActionListener((ActionEvent e) -> {
             String texto = textField.getText(); // Recupera o texto do campo
             label.setText(texto); // Define o texto do rótulo
             textField.setText(""); // Limpa o campo de texto
             textField.setEnabled(false); // Desabilita o campo de texto
        });
    }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
// Adiciona os componentes à janela
        frame.add(text);
        frame.add(button);
        frame.add(labe);
        // Exibe a janela
        frame.setVisible(true);
    }